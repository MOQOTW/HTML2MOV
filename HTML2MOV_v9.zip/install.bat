@echo off
chcp 65001 >nul
echo ==============================================
echo   HTML2MOV — 达芬奇 HTML 烘焙插件 安装工具
echo ==============================================
echo.

REM 1. 检查 Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Node.js，请先安装 https://nodejs.org/
    pause
    exit /b 1
)
echo [√] Node.js 已检测到

REM 2. 设置工作目录
set BAKER_DIR=C:\Html2FusionBaker
if not exist "%BAKER_DIR%" mkdir "%BAKER_DIR%"

REM 3. 复制所有文件
echo 正在复制文件...
for %%f in (BakeHTML.lua bake.js run_bake.bat bake_with_picker.bat BakeHTML_Config.hta OpenFolder.hta plugin_config.json package.json README.md) do (
    if exist "%%f" (
        copy /Y "%%f" "%BAKER_DIR%\" >nul
        echo   %%f ^> %BAKER_DIR%\
    )
)

REM 4. 安装 Node 依赖
echo.
echo 正在安装 Node.js 依赖 (playwright + ffmpeg) ...
cd /d "%BAKER_DIR%"
call npm install 2>&1
if %errorlevel% neq 0 (
    echo [警告] npm install 失败，请手动执行: cd %BAKER_DIR% ^&^& npm install
)

REM 5. 安装 Playwright 浏览器
echo.
echo 正在安装 Playwright 浏览器 (Chromium) ...
call npx playwright install chromium 2>&1
if %errorlevel% neq 0 (
    echo [警告] 浏览器安装失败，烘焙时可能使用系统 Edge 作为后备
)

REM 6. 部署到达芬奇
echo.
echo 正在部署到达芬奇...
set "DST1=%ProgramData%\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Comp"
set "DST2=%AppData%\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Comp"

if not exist "%DST1%" mkdir "%DST1%" 2>nul
copy /Y "%BAKER_DIR%\BakeHTML.lua" "%DST1%\" >nul 2>&1
if %errorlevel% equ 0 (echo [√] 已部署到: %DST1%) else (echo [x] 部署失败: %DST1%)

if not exist "%DST2%" mkdir "%DST2%" 2>nul
copy /Y "%BAKER_DIR%\BakeHTML.lua" "%DST2%\" >nul 2>&1
if %errorlevel% equ 0 (echo [√] 已部署到: %DST2%) else (echo [!] 用户路径已跳过（非关键）)

echo.
echo ==============================================
echo   安装完成！
echo.
echo   使用: 达芬奇 Fusion 页 → Workspace → Scripts → Comp → BakeHTML
echo   配置: 编辑 %BAKER_DIR%\plugin_config.json
echo   文档: %BAKER_DIR%\README.md
echo ==============================================
pause
