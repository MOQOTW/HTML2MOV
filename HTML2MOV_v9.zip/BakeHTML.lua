-- BakeHTML.lua — 达芬奇 Fusion 插件 v9
-- 达芬奇原生 AskUser + HTA 回退，双界面：
--   Browse 选文件 / Text 手动输入 / 选默认文件夹 / 自定义输出文件名 / 默认仅MOV

local fusion = fusion
local comp = fusion and fusion:GetCurrentComp()

local _orig_print = print
local _trace_path = "C:\\Html2FusionBaker\\_lua_trace.log"
pcall(function() local f = io.open(_trace_path, "wb"); if f then f:close() end end)
print = function(...)
  local a = {...}; local s = ""
  for i = 1, #a do s = s .. tostring(a[i]) .. "\t" end
  s = s:gsub("[\r\n]+", " ")
  pcall(function()
    local f = io.open(_trace_path, "a")
    if f then f:write(os.date("%H:%M:%S") .. "\t" .. s .. "\n"); f:close() end
  end)
  _orig_print(...)
end

print("[BakeHTML] v9 启动。")

local BAKER_DIR = "C:\\Html2FusionBaker"

-- 打开文件夹（通过 HTA 代理，支持中文路径）
local function openFolder(path)
  path = (path or ""):gsub("/", "\\")
  if path == "" then return end
  pcall(function()
    local f = io.open(BAKER_DIR .. "\\_folder_to_open.txt", "wb")
    if f then f:write(path); f:close() end
  end)
  os.execute('mshta "' .. BAKER_DIR .. '\\OpenFolder.hta"')
end

local function readJSON(p)
  local f = io.open(p, "r")
  if not f then return nil end
  local t = f:read("*a"); f:close()
  local r = {}
  for k, v in t:gmatch('"([%w_]+)"%s*:%s*(%d+)') do r[k] = v end
  for k, v in t:gmatch('"([%w_]+)"%s*:%s*"([^"]*)"') do r[k] = v:gsub("/", "\\") end
  return r
end

-- 加载默认值（默认仅MOV: outmode=1）
local D = { output_dir = BAKER_DIR .. "\\baked_frames", html_path = "",
            width = 2560, height = 1440, fps = 25, duration = 2,
            outmode = 1, media_pool = 1, outname = "HTML_Baked" }
pcall(function()
  local c = readJSON(BAKER_DIR .. "\\plugin_config.json")
  if c then
    if c.output_dir and c.output_dir ~= "" then D.output_dir = c.output_dir end
    if c.html_path  then D.html_path  = c.html_path  end
    if c.width      then D.width      = tonumber(c.width)  or D.width  end
    if c.height     then D.height     = tonumber(c.height) or D.height end
    if c.fps        then D.fps        = tonumber(c.fps)    or D.fps    end
    if c.duration   then D.duration   = tonumber(c.duration)or D.duration end
    if c.outmode    then D.outmode    = tonumber(c.outmode)or D.outmode end
    if c.media_pool then D.media_pool = tonumber(c.media_pool) or D.media_pool end
    if c.outname    and c.outname ~= "" then D.outname = c.outname end
  end
end)
pcall(function() local f = io.open(BAKER_DIR .. "\\_last_html.txt", "r")
  if f then local v = f:read("*a"):gsub("[\r\n]+", ""); f:close(); if v ~= "" then D.html_path = v end end end)
pcall(function() local f = io.open(BAKER_DIR .. "\\_last_output_dir.txt", "r")
  if f then local v = f:read("*a"):gsub("[\r\n]+", ""):gsub("/", "\\"); f:close(); if v ~= "" then D.output_dir = v end end end)
pcall(function() local f = io.open(BAKER_DIR .. "\\_last_outname.txt", "r")
  if f then local v = f:read("*a"):gsub("[\r\n]+", ""); f:close(); if v ~= "" then D.outname = v end end end)

-- ============ 达芬奇原生 AskUser ============
if not comp then
  print("[BakeHTML] 无合成，回退 HTA...")
  os.execute('mshta "' .. BAKER_DIR .. '\\BakeHTML_Config.hta"')
else
  print("[BakeHTML] 达芬奇原生 UI...")
  -- 输出文件名 = 输入 HTML 文件名（自动同步，无需手动输入）
  local ret = comp:AskUser("BakeHTML — HTML 烘焙", {
    {"htmlBrowse", Name = "选择 HTML 文件",    "FileBrowse", Default = D.html_path},
    {"outBrowse",  Name = "默认输出文件夹",     "PathBrowse", Default = D.output_dir},
    {"width",      Name = "宽度",             "Slider",     Default = D.width,  Min = 100, Max = 7680, Integer = true},
    {"height",     Name = "高度",             "Slider",     Default = D.height, Min = 100, Max = 4320, Integer = true},
    {"fps",        Name = "帧率 FPS",         "Slider",     Default = D.fps,    Min = 1,   Max = 120},
    {"dur",        Name = "时长(秒)",          "Slider",     Default = D.duration, Min = 0.1, Max = 600},
    {"outmode",    Name = "输出模式",          "Dropdown",   Default = D.outmode, Options = {"PNG序列 + MOV", "仅 MOV", "仅 PNG序列"}},
  })

  if not ret then print("[BakeHTML] 取消。"); return end

  -- HTML: 只用 Browse
  local htmlPath = tostring(ret.htmlBrowse or ""):gsub("[\r\n]+", ""):gsub("/", "\\")
  if htmlPath == "" then print("[BakeHTML] 未选择 HTML 文件。"); return end

  -- 输出文件名始终从选中的 HTML 文件名推导（AskUser 无法动态更新，故忽略手动输入）
  local outName = htmlPath:match("([^\\]+)%.[^%.\\]+$") or htmlPath:match("([^\\]+)$") or "HTML_Baked"

  local outDir   = tostring(ret.outBrowse or D.output_dir):gsub("[\r\n]+", ""):gsub("/", "\\")
  if outDir == "" then outDir = D.output_dir end
  local w  = tonumber(ret.width)  or D.width
  local h  = tonumber(ret.height) or D.height
  local fp = tonumber(ret.fps)    or D.fps
  local d  = tonumber(ret.dur)    or D.duration
  local om = tonumber(ret.outmode) or D.outmode

  print(string.format("[BakeHTML] HTML: %s", htmlPath))
  print(string.format("[BakeHTML] 输出: %s\\%s.mov", outDir, outName))
  print(string.format("[BakeHTML] %dx%d @%sfps %.1fs outmode=%d", w, h, fp, d, om))

  -- 记住选择
  pcall(function() local f = io.open(BAKER_DIR .. "\\_last_html.txt", "wb"); if f then f:write(htmlPath); f:close() end end)
  pcall(function() local f = io.open(BAKER_DIR .. "\\_last_output_dir.txt", "wb"); if f then f:write(outDir); f:close() end end)
  pcall(function() local f = io.open(BAKER_DIR .. "\\_last_outname.txt", "wb"); if f then f:write(outName); f:close() end end)

  -- 桥接
  pcall(function() local f = io.open(BAKER_DIR .. "\\_bake_in.txt", "wb"); if f then f:write(htmlPath); f:close() end end)
  pcall(function() local f = io.open(BAKER_DIR .. "\\_bake_out.txt", "wb"); if f then f:write(outDir); f:close() end end)
  local args = string.format("width=%d\nheight=%d\nfps=%d\nduration=%d\noutmode=%d\nsubhz=60\nsettle=400\nheaded=0\n",
    math.floor(w), math.floor(h), math.floor(fp), math.floor(d), math.floor(om))
  pcall(function() local f = io.open(BAKER_DIR .. "\\_bake_args.txt", "wb"); if f then f:write(args); f:close() end end)
  -- 重命名目标（bake.js 用 Node fs 读取，原生 UTF-8，支持中文文件名）
  local renameName = outName .. ".mov"
  local renamePath = outDir .. "\\" .. outName .. ".mov"
  pcall(function() local f = io.open(BAKER_DIR .. "\\_bake_rename_to.txt", "wb"); if f then f:write(renamePath); f:close() end end)

  print("[BakeHTML] 烘焙中（达芬奇短暂冻结）...")
  local bok = os.execute(BAKER_DIR .. "\\run_bake.bat")
  if bok == false or bok == nil or (type(bok) == "number" and bok ~= 0) then
    print("[BakeHTML] 烘焙失败，退出码: " .. tostring(bok))
    return
  end
end

-- ============ 读 manifest（共用）============
local outDir = D.output_dir
pcall(function() local f = io.open(BAKER_DIR .. "\\_last_output_dir.txt", "r")
  if f then local v = f:read("*a"):gsub("[\r\n]+", ""):gsub("/", "\\"); f:close(); if v ~= "" then outDir = v end end end)

local m = readJSON(outDir .. "\\bake_manifest.json")
if not m or not m.first or not m.count then
  print("[BakeHTML] 未找到 manifest（" .. outDir .. "），烘焙可能未产出帧。")
  return
end

-- ============ 结果展示 ============
local movFile = (m.mov and m.mov ~= "" and m.mov) or "(仅 PNG 序列)"
local resultInfo = string.format(
  "文件夹: %s\n文件: %s\n帧数: %s  分辨率: %sx%s  帧率: %s fps\n\n请到文件夹中拖拽文件到达芬奇媒体池。",
  outDir, movFile, m.count, m.width, m.height, m.fps)

if comp then
  -- 达芬奇原生 UI：结果对话框
  local ret2 = comp:AskUser("BakeHTML — 烘焙完成", {
    {"info",  Name = "输出详情",       "Text",     Default = resultInfo, Lines = 5, Wrap = true},
    {"open",  Name = "打开输出文件夹",  "Checkbox", Default = true},
  })
  if ret2 and ret2.open then
    openFolder(outDir)
  end
else
  -- HTA 回退路径：结果在 HTA 中已显示，这里仅打印 + 尝试打开文件夹
  print("[BakeHTML] " .. resultInfo:gsub("\n", " | "))
  openFolder(outDir)
end

print(string.format("[BakeHTML] 完成。输出: %s", outDir))
