# HTML2MOV — 达芬奇 HTML 动画烘焙插件

将任意 HTML 动画一键烘焙为 **ProRes 4444 MOV（含 Alpha 透明通道）**，直接导入 DaVinci Resolve 使用。

[![DaVinci Resolve](https://img.shields.io/badge/DaVinci%20Resolve-18%2B-blue)](https://www.blackmagicdesign.com/products/davinciresolve)
[![Windows](https://img.shields.io/badge/Windows-10%2F11-0078D6)]()
[![License](https://img.shields.io/badge/license-MIT-green)]()

---

## 快速安装

```bash
# 1. 下载本项目所有文件到 C:\Html2FusionBaker\
# 2. 双击运行
install.bat
```

install.bat 会依次完成：
- ✅ 检查 Node.js
- ✅ 复制文件到工作目录
- ✅ npm install（playwright + ffmpeg）
- ✅ 安装 Chromium 浏览器
- ✅ 部署插件到达芬奇

---

## 使用

1. 打开 DaVinci Resolve → 剪辑页 → 新建 **Fusion 合成**
2. **Fusion 页** → 顶部菜单 **Workspace → Scripts → Comp → BakeHTML**
3. 弹出达芬奇原生对话框：
   - 📄 选择 HTML 文件
   - 📁 选择输出文件夹
   - 🎛️ 调整分辨率 / 帧率 / 时长 / 输出模式
4. 点击确定 → 等待烘焙 → 自动弹出文件夹 → 拖 MOV 入媒体池

![使用流程](https://via.placeholder.com/800x400?text=BakeHTML+UI+Screenshot)

## 输出模式

| 模式 | 产物 |
|------|------|
| 仅 MOV | `文件名.mov`（ProRes 4444 含 Alpha） |
| PNG + MOV | PNG 序列 + MOV 视频 |
| 仅 PNG | PNG 序列 `frame_0001.png` … |

## 文件说明

```
C:\Html2FusionBaker\
├── BakeHTML.lua          ← 达芬奇 Fusion 插件
├── bake.js               ← 核心烘焙引擎 (Node.js)
├── run_bake.bat          ← 烘焙启动器
├── BakeHTML_Config.hta   ← 配置窗口（备用）
├── OpenFolder.hta        ← 打开文件夹工具
├── plugin_config.json    ← 默认参数配置
├── package.json          ← npm 依赖
├── install.bat           ← 一键安装脚本
└── README.md             ← 本文档
```

## 配置

编辑 `C:\Html2FusionBaker\plugin_config.json`：

```json
{
  "width": 2560,
  "height": 1440,
  "fps": 25,
  "duration": 2,
  "outmode": 1,
  "output_dir": "C:\\Html2FusionBaker\\baked_frames"
}
```

| 参数 | 说明 |
|------|------|
| `width` × `height` | 默认分辨率 |
| `fps` | 默认帧率 |
| `duration` | 默认时长（秒）|
| `outmode` | 0=PNG+MOV, **1=仅MOV**, 2=仅PNG |
| `output_dir` | 默认输出目录 |

## 原理

```
HTML 页面
  → 无头 Chromium 加载
  → 虚拟时钟接管 (performance.now / rAF / setInterval)
  → 逐帧截图 (透明背景 PNG)
  → ffmpeg 封装 ProRes 4444 MOV (Alpha)
  → 自动打开文件夹，拖入达芬奇
```

## 要求

- Windows 10 / 11
- DaVinci Resolve 18+
- Node.js 16+ [下载](https://nodejs.org/)

## License

MIT
