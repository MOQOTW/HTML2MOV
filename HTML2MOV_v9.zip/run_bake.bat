@echo off
rem run_bake.bat - HTML2MOV launcher
chcp 65001 >nul
title HTML2MOV - baking...

set BAKER=C:\Html2FusionBaker

rem Auto-detect Edge path
set EDGE=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe
if not exist "%EDGE%" set EDGE=C:\Program Files\Microsoft\Edge\Application\msedge.exe

node "%BAKER%\bake.js" --html-file "%BAKER%\_bake_in.txt" --args-file "%BAKER%\_bake_args.txt" --edge "%EDGE%" --out-file "%BAKER%\_bake_out.txt"

if %ERRORLEVEL% neq 0 (
  echo ======== BAKE FAILED ========
  echo Log: %BAKER%\_bake_run.log
)
