@echo off
chcp 65001 >nul
set NODE_PATH=C:\Users\25826\.workbuddy\binaries\node\workspace\node_modules
cd /d C:\Html2FusionBaker

echo ==============================================================
echo   BakeHTML - Step 1: Select HTML file (file dialog)
echo ==============================================================

REM Launch HTA file picker (blocks until user selects and closes)
mshta "C:\Html2FusionBaker\PickHTML.hta"

REM Check if user actually selected a file
if not exist "C:\Html2FusionBaker\_last_html.txt" (
  echo.
  echo ==============================================================
  echo   No file selected. Bake cancelled.
  echo ==============================================================
  pause
  exit /b 1
)

echo ==============================================================
echo   BakeHTML - Step 2: Baking now, please wait...
echo   Log: C:\Html2FusionBaker\_bake_run.log
echo ==============================================================

REM Read HTML path from _last_html.txt and write bridge files
set /p HTML_PATH=<"C:\Html2FusionBaker\_last_html.txt"
echo %HTML_PATH%> "C:\Html2FusionBaker\_bake_in.txt"

REM Run the bake
"C:\Users\25826\.workbuddy\binaries\node\versions\22.22.2\node.exe" "C:\Html2FusionBaker\bake.js" --html-file "C:\Html2FusionBaker\_bake_in.txt" --args-file "C:\Html2FusionBaker\_bake_args.txt" --edge "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --out-file "C:\Html2FusionBaker\_bake_out.txt"

set RC=%ERRORLEVEL%
if not "%RC%"=="0" (
  echo.
  echo ============ BAKE FAILED, exit code %RC% ============
  echo See C:\Html2FusionBaker\_bake_run.log for details.
  echo ==============================================================
  pause
  exit /b %RC%
)

echo.
echo ==============================================================
echo   Bake complete! Returning to DaVinci...
echo ==============================================================
exit /b 0
