#!/usr/bin/env node
/**
 * Html2Fusion — 任意 HTML 动画 → 带 Alpha 通道的 PNG 序列（Fusion Loader 直读）
 *
 * 机理（确定性烘焙，非实时）：
 *  1. 启动无头 Chromium（默认驱动系统 Edge，免去下载 Chromium）。
 *  2. 在页面脚本运行前注入"虚拟时钟"：劫持 performance.now / Date.now /
 *     requestAnimationFrame / setInterval，使时间完全由我们控制。
 *  3. 逐帧推进：设虚拟时间 = i/fps 秒，冲刷所有待执行的 rAF/interval 回调；
 *     若页面暴露 window.renderAt(t)（秒），优先调用它（最精准）。
 *  4. 每帧 page.screenshot({ omitBackground:true }) → PNG 透明背景。
 *
 * 适用：DeepSeek / 任意大模型生成的粒子特效、MG 动画、平面动效 HTML。
 *
 * 用法：
 *   node bake.js <input.html> [--fps 30] [--duration 18] [--width 1920] [--height 1080] [--out frames]
 * 若 HTML 内声明 window.__BAKE__ = {fps,duration,width,height}，则以此为准。
 */

const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
// GBK/系统代码页解码（Fusion Lua 在某些情况下按系统编码写路径）。缺失则跳过该候选。
let iconvLite = null;
try { iconvLite = require('iconv-lite'); } catch (e) {}

// -------- 双写日志：控制台实时显示 + 自动落盘 _bake_run.log（bat 不再重定向）--------
const LOGFILE = path.join(__dirname, '_bake_run.log');
try { fs.writeFileSync(LOGFILE, '===== bake run ' + new Date().toISOString() + ' =====\r\n'); } catch (e) {}
function __tee(s) { try { fs.appendFileSync(LOGFILE, s + '\r\n'); } catch (e) {} }
const __log = console.log.bind(console);
const __err = console.error.bind(console);
console.log = (...a) => { const s = a.map(String).join(' '); __log(s); __tee(s); };
console.error = (...a) => { const s = a.map(String).join(' '); __err(s); __tee(s); };

// -------- 桥接文件多编码解码（共用） --------
// Fusion Lua 写出的桥接文件可能是 UTF-8 或 GBK(系统代码页) 字节。
// 依次尝试候选编码，用 validate(path) 判断哪个解码结果是"真实存在"的路径。
function decodeBridgeFile(fp, validate) {
  const raw = fs.readFileSync(fp);
  const candidates = [raw.toString('utf8')];
  if (iconvLite) {
    try { candidates.push(iconvLite.decode(raw, 'gbk')); } catch (e) {}
    try { candidates.push(iconvLite.decode(raw, 'gb18030')); } catch (e) {}
  }
  candidates.push(raw.toString('latin1'));
  for (const c of candidates) {
    const p = String(c).replace(/^﻿/, '').replace(/\r?\n/g, '').trim();
    if (!p) continue;
    const rp = path.resolve(p);
    if (validate(rp)) return rp;
  }
  return { failed: true, candidates, raw };
}

// -------- 参数解析 --------
function parseArgs(argv) {
  const opts = {
    input: null,
    fps: 30,
    duration: 18,
    width: 1920,
    height: 1080,
    out: 'frames',
    settle: 400,        // 页面加载后稳定等待(ms)
    edge: process.env.EDGE_PATH || 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    headless: true,
    substepHz: 60,       // 虚拟时钟子步进频率：以 60Hz 细粒度推进，消除"逐帧累加型"动画跳帧/不连贯
    makeMov: false,      // 烘完自动封装带 Alpha 的 ProRes 4444 MOV
    keepPng: true,       // 是否保留 PNG 序列（"仅 MOV"模式下编码成功后删除中间帧）
    argsFile: null,      // 由 Lua 写出的 ASCII 参数桥接文件（分辨率/帧率/时长/输出内容）
  };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--fps') opts.fps = +argv[++i];
    else if (a === '--duration') opts.duration = +argv[++i];
    else if (a === '--width') opts.width = +argv[++i];
    else if (a === '--height') opts.height = +argv[++i];
    else if (a === '--out') opts.out = argv[++i];
    else if (a === '--settle') opts.settle = +argv[++i];
    else if (a === '--edge') opts.edge = argv[++i];
    else if (a === '--headed') opts.headless = false;
    else if (a === '--args-file') opts.argsFile = argv[++i];
    else if (a === '--make-mov') opts.makeMov = true;
    else if (a === '--substep-hz') opts.substepHz = +argv[++i];
    else if (a === '--html-file') {
      const fp = argv[++i];
      try {
        // 以"文件确实存在"为唯一判据做多编码解码（UTF-8/GBK/GB18030/Latin1）。
        const r = decodeBridgeFile(fp, (p) => fs.existsSync(p) && fs.statSync(p).isFile());
        if (r && r.failed) {
          console.error('[html-file] 桥接文件中的路径无法匹配真实文件。已尝试的解码候选:');
          r.candidates.forEach((c, i) => console.error('   [' + i + '] ' + JSON.stringify(String(c).replace(/\r?\n/g, '').trim())));
          console.error('   桥接文件原始十六进制(前64字节): ' + r.raw.slice(0, 64).toString('hex'));
          process.exit(1);
        }
        opts.input = r;
      } catch (e) {
        console.error('[html-file] 无法读取 HTML 路径文件: ' + e.message);
        process.exit(1);
      }
    }
    else if (a === '--out-file') {
      // 自定义输出文件夹桥接（可能含中文）。判据："该目录存在"或"其父目录存在"
      //（目录本身可不存在，稍后 mkdirSync recursive 会创建）。
      const fp = argv[++i];
      try {
        if (fs.existsSync(fp)) {
          // 两轮判定：① 目录本身已存在（最强判据）；
          // ② 回退"父目录存在"，但拒绝含 U+FFFD 替换符的候选——
          //    GBK 字节被 UTF-8 错误解码必产生 U+FFFD，若不过滤会把帧写进乱码目录。
          let r = decodeBridgeFile(fp, (p) => fs.existsSync(p) && fs.statSync(p).isDirectory());
          if (r && r.failed) {
            r = decodeBridgeFile(fp, (p) => p.indexOf('\uFFFD') === -1 && fs.existsSync(path.dirname(p)));
          }
          if (r && !r.failed) {
            opts.out = r;
            console.log('[out] 自定义输出文件夹: ' + r);
          } else {
            console.log('[out] 输出文件夹桥接解码失败，回退默认输出目录。');
            if (r && r.candidates) r.candidates.forEach((c, i) => console.log('   [' + i + '] ' + JSON.stringify(String(c).replace(/\r?\n/g, '').trim())));
          }
        }
      } catch (e) {
        console.log('[out] 读取输出文件夹桥接失败(' + e.message + ')，使用默认输出目录。');
      }
    }
    else if (!opts.input) opts.input = a;
  }
  // 参数桥接文件（ASCII key=value，每行一项）：width/height/fps/duration/mov
  // 由 BakeHTML.lua 的设置对话框写出，路径无中文，规避 cmd 参数传递的一切编码/引号坑。
  if (opts.argsFile) {
    try {
      const txt = fs.readFileSync(opts.argsFile, 'latin1');
      txt.split(/\r?\n/).forEach((line) => {
        // 数值参数: key=数字
        const m = line.match(/^\s*([a-zA-Z_]+)\s*=\s*([\d.]+)\s*$/);
        // 字符串参数: key="值" 或 key=值
        const ms = line.match(/^\s*([a-zA-Z_]+)\s*=\s*"([^"]*)"\s*/) || line.match(/^\s*([a-zA-Z_]+)\s*=\s*([^\r\n]+)\s*$/);
        if (m) {
          const k = m[1].toLowerCase(); const v = +m[2];
          if (!isFinite(v)) return;
          if (k === 'width' && v >= 16) opts.width = Math.round(v);
          else if (k === 'height' && v >= 16) opts.height = Math.round(v);
          else if (k === 'fps' && v > 0) opts.fps = v;
          else if (k === 'duration' && v > 0) opts.duration = v;
          else if (k === 'mov') opts.makeMov = (v === 1);
          else if (k === 'subhz' && v >= 30) opts.substepHz = Math.min(240, Math.round(v));
          else if (k === 'settle' && v >= 0) opts.settle = Math.max(0, Math.round(v));
          else if (k === 'headed') opts.headless = (v === 0);
          else if (k === 'outmode') {
            if (v === 1) { opts.makeMov = true; opts.keepPng = false; }
            else if (v === 2) { opts.makeMov = false; opts.keepPng = true; }
            else { opts.makeMov = true; opts.keepPng = true; }
          }
        } else if (ms) {
          const ks = ms[1].toLowerCase(); const vs = (ms[2] || '').trim();
          if (ks === 'outname' && vs) opts.outname = vs;
        }
      });
      console.log('[args] 采用设置: ' + opts.width + 'x' + opts.height + ' @' + opts.fps + 'fps, ' + opts.duration + 's, mov=' + (opts.makeMov ? '1' : '0') + ', keepPng=' + (opts.keepPng ? '1' : '0') + ', subHz=' + opts.substepHz + ', settle=' + opts.settle + 'ms, headless=' + (opts.headless ? '1' : '0'));
    } catch (e) {
      console.log('[args] 未读到参数文件(' + e.message + ')，使用默认设置。');
    }
  }
  return opts;
}

// -------- 虚拟时钟注入（在任何页面脚本前执行） --------
const INIT_SCRIPT = () => {
  const w = window;
  w.__vclock = 0;
  w.__raf = [];
  w.__intervals = new Map();
  w.__timeouts = new Map();
  let __iid = 1;
  if (w.performance && typeof w.performance.now === 'function') {
    w.performance.now = () => w.__vclock;
  }
  const _DateNow = Date.now;
  Date.now = () => w.__vclock;
  w.requestAnimationFrame = (cb) => { w.__raf.push(cb); return w.__raf.length; };
  w.cancelAnimationFrame = () => {};
  // 关键：last 从"注册时刻"起算（而非 -1e9）。否则首次 flush 会补偿式连发
  // 上万次回调，把页面自跑时钟(如 simTime += 0.05 的降级 interval)快进几百秒，
  // 导致烘出的帧与浏览器实际播放完全不一致。
  w.setInterval = (cb, period) => {
    const id = __iid++;
    w.__intervals.set(id, { cb, period: period || 16, last: w.__vclock });
    return id;
  };
  w.clearInterval = (id) => { w.__intervals.delete(id); };
  // setTimeout 也纳入虚拟时钟（覆盖递归 setTimeout 型动画）
  w.setTimeout = (cb, delay) => {
    const id = __iid++;
    w.__timeouts.set(id, { cb, due: w.__vclock + (delay || 0) });
    return id;
  };
  w.clearTimeout = (id) => { w.__timeouts.delete(id); };
  // 推进虚拟时间并冲刷所有回调
  w.__flush = (tMs) => {
    w.__vclock = tMs;
    const cbs = w.__raf; w.__raf = [];
    for (const cb of cbs) { try { cb(tMs); } catch (e) {} }
    w.__intervals.forEach((iv) => {
      let guard = 0;
      while (tMs - iv.last >= iv.period && guard < 1000) {
        iv.last += iv.period;
        try { iv.cb(tMs); } catch (e) {}
        guard++;
      }
    });
    // 到期的 setTimeout（回调可能再注册新的，循环直至无到期项）
    let tguard = 0;
    while (tguard < 1000) {
      let fired = false;
      for (const entry of Array.from(w.__timeouts)) {
        const id = entry[0], o = entry[1];
        if (o.due <= tMs) { w.__timeouts.delete(id); try { o.cb(); } catch (e) {} fired = true; }
      }
      if (!fired) break;
      tguard++;
    }
  };
  // 页面加载后暂停所有 CSS 动画（防止真实时间轴抢跑）
  w.addEventListener('DOMContentLoaded', () => {
    try {
      if (document.documentElement) {
        document.documentElement.style.setProperty('animation-play-state', 'paused', 'important');
      }
      if (document.body) {
        document.body.style.setProperty('animation-play-state', 'paused', 'important');
      }
    } catch (e) {}
  });
};

async function main() {
  const opts = parseArgs(process.argv);
  if (!opts.input) {
    console.error('[ERR] 缺少输入 HTML 文件。用法: node bake.js <input.html> [--fps 30] [--duration 18] ...');
    process.exit(1);
  }
  const inputPath = path.resolve(opts.input);
  if (!fs.existsSync(inputPath)) { console.error('[ERR] 文件不存在: ' + inputPath); process.exit(1); }

  console.log('[1/6] 启动无头浏览器 (Edge) ...');
  const launchOpts = {
    headless: opts.headless,
    executablePath: opts.edge,
    args: ['--no-sandbox', '--disable-gpu', '--force-color-profile=srgb', '--hide-scrollbars'],
  };
  let browser;
  try {
    browser = await chromium.launch(launchOpts);
  } catch (e) {
    console.error('[ERR] 无法启动 Edge: ' + e.message);
    console.error('      请确认 Edge 路径，或用 --edge 指定；也可装 Playwright Chromium: npx playwright install chromium');
    process.exit(1);
  }

  const page = await browser.newPage({
    viewport: { width: opts.width, height: opts.height },
    deviceScaleFactor: 1,
  });
  await page.addInitScript(INIT_SCRIPT);

  console.log('[2/6] 载入页面: ' + inputPath);
  await page.goto('file://' + inputPath.replace(/\\/g, '/'), { waitUntil: 'load' });
  await page.waitForTimeout(opts.settle);

  // 读取页面自述配置（若存在）
  const cfg = await page.evaluate(() => (typeof window.__BAKE__ === 'object' && window.__BAKE__) ? window.__BAKE__ : null);
  const fps = (cfg && cfg.fps) ? cfg.fps : opts.fps;
  const duration = (cfg && cfg.duration) ? cfg.duration : opts.duration;
  const width = (cfg && cfg.width) ? cfg.width : opts.width;
  const height = (cfg && cfg.height) ? cfg.height : opts.height;
  if (cfg) console.log('[cfg] 采用页面 __BAKE__: ' + JSON.stringify(cfg));

  // 若尺寸与初始 viewport 不一致，调整
  if (width !== opts.width || height !== opts.height) {
    await page.setViewportSize({ width, height });
  }

  const hasRenderAt = await page.evaluate(() => typeof window.renderAt === 'function');
  const hasClock = await page.evaluate(() => (window.__raf && window.__raf.length > 0) || window.__intervals.size > 0);
  console.log('[3/6] 检测: renderAt=' + hasRenderAt + '  rAF/interval回调=' + hasClock);

  const total = Math.max(1, Math.round(duration * fps));
  const outDir = path.resolve(opts.out);
  fs.mkdirSync(outDir, { recursive: true });
  const pad = String(total).length;
  const frameName = (i) => path.join(outDir, 'frame_' + String(i + 1).padStart(Math.max(4, pad), '0') + '.png');

  console.log(`[4/6] 烘焙 ${total} 帧 @ ${fps}fps (${width}x${height}) → ${outDir}`);
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  // 子步进周期：虚拟时钟内部按 substepHz（默认60Hz，与真实浏览器刷新率一致）细粒度推进。
  // 意义：若输出 fps < 60，"逐帧累加型" rAF/interval 动画（每 tick 前进固定增量的写法）
  // 在旧逻辑下每输出帧只被冲刷一次 → 动画只走了一半的步数 → 跳帧/变慢/与浏览器不对齐。
  //
  // 关键（丢帧修复）：tick 必须走【绝对整数计数的固定网格】，绝不能在帧边界把
  // 时钟重置到帧时刻——否则当 fps 不整除 60（如 24/25fps）时，每帧会插入一个
  // 8~10ms 的"半步 tick"且网格逐帧错位 → rAF 触发 ~72次/秒（真实浏览器=60）
  // 且节奏忽长忽短 → 累加型动画忽快忽慢，成片表现为丢帧/失帧/运动不连贯。
  // 帧时刻的取样精度由"最后一个 tick 的时间戳定格到 tMs + 权威时间派发"保证。
  const subHz = Math.max(fps, Math.min(240, Math.max(30, opts.substepHz)));
  const subMs = 1000 / subHz;
  let tick = 0; // 绝对 tick 计数（固定网格 tick*subMs，跨帧永不重置）

  for (let i = 0; i < total; i++) {
    const tSec = i / fps;
    const tMs = tSec * 1000;
    // 1) 均匀网格推进到本帧时刻（页面自跑动画按真实 60Hz 节奏逐 tick 前进）
    const steps = [];
    while ((tick + 1) * subMs <= tMs + 1e-6) { tick++; steps.push(tick * subMs); }
    if (steps.length > 0) steps[steps.length - 1] = tMs; // 末 tick 定格到帧时刻（取样精确，网格计数不变）
    else if (i === 0) steps.push(0); // 首帧：t=0 冲刷一次，与真实浏览器首帧行为一致
    await page.evaluate(({ steps, tMs, tSec }) => {
      // 顺序关键：先按子步冲刷 rAF/interval/timeout 虚拟时钟（页面自跑动画），
      // 最后派发"权威时间"驱动——确保逐帧精确状态胜出。
      if (typeof window.__flush === 'function') {
        for (const s of steps) window.__flush(s);
      }
      // 2) 接管 CSS/WAAPI 动画 + CSS Transitions
      try {
        // CSS 全页面暂停动画播放（防止真实时间轴干扰）
        if (document.documentElement) {
          document.documentElement.style.animationPlayState = 'paused';
        }
        // WAAPI/CSS animations：定格到虚拟时间
        if (document.getAnimations) {
          for (const a of document.getAnimations()) {
            try {
              if (a.playState !== 'paused') a.pause();
              a.currentTime = tMs;
            } catch (e) {}
          }
        }
      } catch (e) {}
      // 3) 权威时间最后派发
      if (typeof window.renderAt === 'function') {
        try { window.renderAt(tSec); } catch (e) {}
      } else {
        // OGraf 风格：监听 ograf:time 自定义事件（detail=秒）
        try { window.dispatchEvent(new CustomEvent('ograf:time', { detail: tSec })); } catch (e) {}
      }
    }, { steps, tMs, tSec });
    await page.screenshot({ path: frameName(i), omitBackground: true, type: 'png' });
    if ((i + 1) % Math.max(1, Math.round(total / 20)) === 0 || i === total - 1) {
      process.stdout.write(`\r      进度 ${i + 1}/${total}`);
      __tee(`      progress ${i + 1}/${total}`);
    }
  }
  console.log('');

  await browser.close();

  // 首帧透明度自检（验证确实带 Alpha）——须在可能删除 PNG 之前做
  console.log('[5/6] 校验输出 Alpha 通道 ...');
  const first = frameName(0);
  const verdict = await checkAlpha(first);

  // 可选：自动封装带 Alpha 的 MOV（ProRes 4444，剪辑软件通吃）
  let mov = { ok: false, movPath: '', msg: '' };
  if (opts.makeMov) {
    mov = encodeMov(outDir, total, fps, opts.outname || 'HTML_Baked');
  }

  // "仅 MOV"模式：编码成功后删除 PNG 中间帧；编码失败则保留 PNG 兜底（绝不两头空）。
  let pngKept = true;
  if (!opts.keepPng) {
    if (mov.ok) {
      let removed = 0;
      for (let i = 0; i < total; i++) {
        try { fs.unlinkSync(frameName(i)); removed++; } catch (e) {}
      }
      pngKept = false;
      console.log('[clean] 仅视频模式：已删除 ' + removed + ' 张 PNG 中间帧（MOV 已成功生成）。');
    } else {
      console.log('[clean] MOV 未成功生成，保留 PNG 序列作为兜底（不删除）。');
    }
  }

  // 写清单，供 Fusion 脚本(BakeHTML.lua)免扫描目录直接读取。
  // mode: png_mov / mov_only / png_only —— Lua 据此决定 Loader 挂 PNG 序列还是 MOV。
  try {
    const mode = pngKept ? (mov.ok ? 'png_mov' : 'png_only') : 'mov_only';
    const manifest = {
      first: path.basename(frameName(0)), count: String(total), fps: String(fps),
      width: String(width), height: String(height), outDir: outDir.replace(/\\/g, '/'),
      mode: mode, mov: mov.ok ? path.basename(mov.movPath) : '',
    };
    fs.writeFileSync(path.join(outDir, 'bake_manifest.json'), JSON.stringify(manifest, null, 2));
  } catch (e) {}

  console.log('[6/6] 完成。输出目录: ' + outDir);
  console.log('      帧数: ' + total + '  尺寸: ' + width + 'x' + height + '  fps: ' + fps);
  if (pngKept) console.log('      Fusion 导入: 把第一帧 ' + path.basename(first) + ' 拖入 Fusion 节点区即可自动识别为序列。');
  if (errors.length) console.log('[warn] 页面运行期报错 ' + errors.length + ' 条（部分动画可能缺帧）: ' + errors.slice(0, 3).join(' | '));
  console.log('[alpha] ' + verdict);
  if (mov.msg) console.log('[mov] ' + mov.msg);
}

// PNG 序列 → ProRes 4444 MOV（yuva444p10le 保留透明通道），使用自包含 ffmpeg-static。
function encodeMov(outDir, total, fps, outName) {
  let ffmpeg = null;
  try { ffmpeg = require('ffmpeg-static'); } catch (e) {}
  if (!ffmpeg || !fs.existsSync(ffmpeg)) {
    try {
      const inst = require('@ffmpeg-installer/ffmpeg');
      if (inst && inst.path && fs.existsSync(inst.path)) ffmpeg = inst.path;
    } catch (e2) {}
  }
  if (!ffmpeg || !fs.existsSync(ffmpeg)) {
    return { ok: false, movPath: '', msg: '跳过：未找到 ffmpeg（在 C:\\Html2FusionBaker 执行 npm install @ffmpeg-installer/ffmpeg 后重试）' };
  }
  const padWidth = Math.max(4, String(total).length);
  const relPattern = 'frame_%0' + padWidth + 'd.png';
  const tmpName = '_bake_tmp_.mov';
  const tmpPath = path.join(outDir, tmpName);
  console.log('[mov] 正在封装 ProRes 4444 (带 Alpha) MOV...');
  const { spawnSync } = require('child_process');
  const r = spawnSync(ffmpeg, [
    '-y', '-framerate', String(fps), '-start_number', '1', '-i', relPattern,
    '-r', String(fps),
    '-c:v', 'prores_ks', '-profile:v', '4444', '-pix_fmt', 'yuva444p10le',
    '-vendor', 'apl0', tmpName,
  ], { cwd: outDir, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  if (r.status === 0 && fs.existsSync(tmpPath)) {
    let finalPath = tmpPath;
    try {
      const renameFile = path.join(outDir, '_bake_rename_to.txt');
      // 尝试从输出目录读，失败则读 baker 根目录（Lua 写中文路径可能失败，故写了 baker 根目录）
      let targetName = null;
      try {
        if (fs.existsSync(renameFile)) targetName = fs.readFileSync(renameFile, 'utf8').trim();
      } catch (e) {}
      if (!targetName) {
        const bakerRename = path.join(__dirname, '_bake_rename_to.txt');
        try {
          if (fs.existsSync(bakerRename)) targetName = fs.readFileSync(bakerRename, 'utf8').trim();
        } catch (e) {}
      }
      if (targetName && targetName !== tmpName) {
        // targetName 现在是完整路径（如 F:\Edge\...\文件名.mov）
        let targetPath = targetName;
        if (!path.isAbsolute(targetPath)) targetPath = path.join(outDir, targetName);
        // 重名避让
        const ext = path.extname(targetPath);
        const base = path.basename(targetPath, ext);
        let dir = path.dirname(targetPath);
        let finalName = path.basename(targetPath);
        let n = 1;
        while (fs.existsSync(targetPath)) {
          finalName = base + '_' + n + ext;
          targetPath = path.join(dir, finalName);
          n++;
        }
        fs.renameSync(tmpPath, targetPath);
        finalPath = targetPath;
        if (n > 1) console.log('[mov] 文件已存在，自动重命名为: ' + finalName);
        else console.log('[mov] 已重命名为: ' + finalName);
      }
    } catch (e) { console.log('[mov] 重命名失败: ' + e.message); }
    const mb = (fs.statSync(finalPath).size / 1048576).toFixed(1);
    return { ok: true, movPath: finalPath, msg: 'MOV 已生成 (' + mb + ' MB)' };
  }
  try { if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath); } catch (e) {}
  const tail = String((r.stderr || '') + (r.error ? r.error.message : '')).slice(-600);
  return { ok: false, movPath: '', msg: 'MOV 封装失败(exit=' + r.status + '): ' + tail };
}

// 用 Node 读 PNG 头判断是否存在 tRNS/24位以上色彩类型(含透明)
function checkAlpha(file) {
  return new Promise((resolve) => {
    try {
      const buf = fs.readFileSync(file);
      if (buf.length < 33) return resolve('PNG 过小，无法判定');
      // IHDR: 宽4 高4 后接 bitDepth(1) colorType(1)
      const colorType = buf.readUInt8(25);
      // colorType: 4=灰度+alpha, 6=RGBA, 3=索引(可能带tRNS), 0=灰度, 2=RGB
      const hasAlpha = (colorType === 4 || colorType === 6);
      resolve(hasAlpha ? '首帧含 Alpha 通道 (colorType=' + colorType + ')，透明有效 ✓' : '首帧 colorType=' + colorType + ' 疑似不透明 — 请确认 HTML body 背景为 transparent');
    } catch (e) { resolve('校验失败: ' + e.message); }
  });
}

main().catch((e) => { console.error('[FATAL] ' + e.stack); process.exit(1); });
